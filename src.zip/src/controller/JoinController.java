package controller;

import dao.JoinDao;
import dto.UserDto;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/join.do")
public class JoinController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("member.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");
        JoinDao dao = new JoinDao();
        int joinResult = 0;

        if ("CheckId".equals(action)) {
            System.out.println("중복체크 로직");
            // 중복 체크 로직
            String user_id = req.getParameter("user_id");
            String idCheckResult = "";

            if (user_id != null && !user_id.trim().isEmpty()) {
                boolean exists = dao.checkUserID(user_id);
                if (exists) {
                    idCheckResult = "사용할 수 없는 아이디입니다.";
                    req.setAttribute("user_id", "");
                } else {
                    idCheckResult = "사용할 수 있는 아이디입니다.";
                    req.setAttribute("user_id", user_id);
                }
            } else {
                idCheckResult = "아이디를 입력해주세요.";
            }
            req.setAttribute("idCheckResult", idCheckResult);
            req.getRequestDispatcher("/member.jsp").forward(req, resp);

        } else if ("register".equals(action)) {
            System.out.println("로그인 로직");
            String user_id = req.getParameter("user_id");
            String password = req.getParameter("password");
            String password2 = req.getParameter("password2");
            // pwd2 와 맞지않으면 로그인 페이지로 다시 보내기
            if (!password.equals(password2)) {
                req.setAttribute("passwordCheck", "비밀번호 확인이 맞지않습니다");
                req.getRequestDispatcher("/member.jsp").forward(req, resp);
            }
            String phone = req.getParameter("phone");
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String birth = req.getParameter("birth");
            String addr = req.getParameter("addr");

            // member.jsp에서 받아온 값 DTO에 넣기
            UserDto dto = new UserDto();
            dto.setUserId(user_id);
            dto.setPassword(password);
            dto.setName(name);
            dto.setEmail(email);
            dto.setPhone(phone);
            dto.setBirth(birth);
            dto.setAddr(addr);
            dto.setGrade(1);

             joinResult = dao.join(dto);
            System.out.println(joinResult);
        }

        if (joinResult == 1) {
            resp.sendRedirect("/main.jsp");
        } else {
            req.setAttribute("msg", "오류로 인한 회원 가입 실패");
            req.getRequestDispatcher("/member.jsp").forward(req, resp);
        }
    }
}
